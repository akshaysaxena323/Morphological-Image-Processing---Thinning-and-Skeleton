# Morphological-Image-Processing
Morphological Image Processing - Thinning and Skeleton

Click to see the video:

[![Morphological-Image-Processing](https://i.ytimg.com/vi/6m6YeMrc8Lo/3.jpg?time=1426802287614)](https://youtu.be/6m6YeMrc8Lo)
